#!/usr/bin/env python3
# ai_menu_wine.py
# Copyright Su Nie
# BSD-C-3 License
# https://www.github.com/can87683


import setproctitle
setproctitle.setproctitle("ai_menu_wine.py")

import os
import sys

# ==============================
# WINE COMPATIBILITY
# ==============================
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["KMP_AFFINITY"] = "disabled"
os.environ["KMP_SETTINGS"] = "0"
os.environ["KMP_WARNINGS"] = "FALSE"

def is_wine() -> bool:
    return os.environ.get('WINELOADERNOEXEC') is not None

def is_windows() -> bool:
    return sys.platform.startswith('win')

def is_wine_or_windows() -> bool:
    return is_wine() or is_windows()

if is_wine():
    print("🍷 Wine environment detected - applying threading optimizations")
    os.environ["OPENBLAS_NUM_THREADS"] = "1"
    os.environ["VECLIB_MAXIMUM_THREADS"] = "1"

import os
import sys
import tkinter as tk
from tkinter import messagebox, filedialog
import configparser
import socket
import requests
import subprocess
import shlex
import psutil
import socket
import requests
import tkinter as tk

try:
    import GPUtil
except ImportError:
    GPUtil = None

REFRESH_INTERVAL = 5 * 60  # 5 minutes in milliseconds

# ==============================
# LAYOUT TUNABLES
# ==============================
PATH_COLUMN_WIDTH = 310      # pixels per path column (2 columns in ~640 window)
SCRIPT_NAME_WIDTH = 15       # characters shown in script name label
BUTTON_WIDTH = 3             # width for Br / R / X buttons

# ==============================
# COLOR SETTINGS
# ==============================
FRAME1_BG = "grey"
FRAME1_FG = "yellow"

FRAME2_BG = "pink"
FRAME2_FG = "blue"

FRAME3_BG = "yellow"
FRAME3_FG = "black"

FRAME4_BG = "lime"
FRAME4_FG = "red"

FRAME5_BG = "green"
FRAME5_FG = "yellow"

BORDER_COLOR = "grey"

# ==============================
# CONFIG & VARIABLES
# ==============================
SETTINGS_FILE = "ai_menu_wine.ini"

default_settings = {
    "window": {"width": "640", "height": "300", "x": "100", "y": "100"},
    "python": {"binary_path": sys.executable},  # Default to current python
    "colors": {
        "frame1_bg": FRAME1_BG,
        "frame1_fg": FRAME1_FG,
        "frame2_bg": FRAME2_BG,
        "frame2_fg": FRAME2_FG,
        "frame3_bg": FRAME3_BG,
        "frame3_fg": FRAME3_FG,
        "frame4_bg": FRAME4_BG,
        "frame4_fg": FRAME4_FG,
        "frame5_bg": FRAME5_BG,
        "frame5_fg": FRAME5_FG,
        "border_color": BORDER_COLOR,
    },
    "paths": {}
}

def load_settings():
    config = configparser.ConfigParser()
    if os.path.exists(SETTINGS_FILE):
        config.read(SETTINGS_FILE)
    else:
        config.read_dict(default_settings)
    if "paths" not in config:
        config["paths"] = {}
    if "python" not in config:
        config["python"] = {"binary_path": sys.executable}
    return config

def save_settings(config):
    with open(SETTINGS_FILE, "w") as f:
        config.write(f)

# ==============================
# MAIN WINDOW
# ==============================
config = load_settings()
width = int(config["window"]["width"])
height = int(config["window"]["height"])
pos_x = int(config["window"]["x"])
pos_y = int(config["window"]["y"])

# Hardcoded *default* Python path (if .ini is messed up)
DEFAULT_PYTHON_BINARY = "/home/user/.venvwine310/Scripts/python.exe"

# Read from config, but fall back to hard‑coded default
try:
    PYTHON_BINARY = config["python"]["binary_path"]
    # If the path is empty or invalid, use default
    if not PYTHON_BINARY or not PYTHON_BINARY.strip():
        PYTHON_BINARY = DEFAULT_PYTHON_BINARY
except (KeyError, configparser.NoSectionError, configparser.NoOptionError):
    PYTHON_BINARY = DEFAULT_PYTHON_BINARY

# Also update config so future saves use the current value
if "python" not in config:
    config["python"] = {}
config["python"]["binary_path"] = PYTHON_BINARY
save_settings(config)


root = tk.Tk()
root.title("App Menu")
root.geometry(f"{width}x{height}+{pos_x}+{pos_y}")
root.resizable(False, False)

# ==============================
# IP DETECTION + ROW
# ==============================
def get_lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "0.0.0.0"

def get_public_ip():
    try:
        return requests.get("https://api.ipify.org", timeout=1.5).text
    except:
        return "0.0.0.0"

def update_ip_label():
    lan = get_lan_ip()
    wan = get_public_ip()
    label_text = f"LAN: {lan}  -  WAN: {wan}"
    ip_label.config(text=label_text)
    root.after(REFRESH_INTERVAL, update_ip_label)

def build_ip_row():
    global ip_label
    ip_frame = tk.Frame(root, bg="#222222", height=40)
    ip_frame.pack(fill="x")

    ip_label = tk.Label(
        ip_frame,
        text="Loading IPs...",
        font=("Arial", 20),
        bg="green",
        fg="white",
        anchor="center",
        justify="center"
    )
    ip_label.pack(expand=True, fill="x")

    update_ip_label()  # initial load + start timer

build_ip_row()

# ==============================
# SYSTEM USAGE ROW (below LAN IP)
# ==============================
import psutil
try:
    import GPUtil
except ImportError:
    GPUtil = None

def build_usage_row():
    usage_frame = tk.Frame(root, bg="grey", height=40)
    usage_frame.pack(fill="x")

    usage_label = tk.Label(
        usage_frame,
        text="Loading system usage...",
        font=("Arial", 16),
        bg="yellow",
        fg="blue",
        anchor="center",
        justify="center"
    )
    usage_label.pack(expand=True, fill="x")

    def update_usage():
        try:
            cpu = psutil.cpu_percent(interval=0.5)
            dram = psutil.virtual_memory().percent
            gpu_percent = 0
            vram_percent = 0
            if GPUtil:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]
                    gpu_percent = gpu.load * 100
                    vram_percent = gpu.memoryUtil * 100
        except Exception:
            cpu = dram = gpu_percent = vram_percent = 0

        usage_label.config(
            text=f"CPU: {cpu:.1f}%   DRAM: {dram:.1f}%   GPU: {gpu_percent:.1f}%   VRAM: {vram_percent:.1f}%"
        )
        usage_label.after(2000, update_usage)  # refresh every 2 seconds

    update_usage()

build_usage_row()

# ==============================
# TOP BUTTON ROW
# ==============================
def popup_module(name):
    popup = tk.Toplevel(root)
    popup.title(name)
    popup.geometry("600x600")
    tk.Label(popup, text=f"{name} Loaded", font=("Arial", 16)).pack(expand=True)
    tk.Button(popup, text="Close", command=popup.destroy).pack(pady=10)

def build_top_buttons():
    top_frame = tk.Frame(root, bg="#222222", height=45)
    top_frame.pack(fill="x")

    for i in range(6):
        top_frame.columnconfigure(i, weight=1)

    button_names = [
        "Module 1", "Module 2", "Module 3",
        "Module 4", "Module 5", "Module 6"
    ]

    for i, name in enumerate(button_names):
        tk.Button(
            top_frame,
            text=name,
            height=2,
            command=lambda n=name: popup_module(n)
        ).grid(row=0, column=i, sticky="nsew", padx=2, pady=2)

build_top_buttons()

# ==============================
# PYTHON PATH + ADD PATH BAR
# ==============================
add_bar = tk.Frame(root, bg=FRAME5_BG)
add_bar.pack(fill="x")

# Python Path Button and Label
def set_python_path():
    global PYTHON_BINARY
    filename = filedialog.askopenfilename(
        title="Select Python 3.10 Binary",
        filetypes=[
            ("Python Binaries", "python3*"),
            ("All Executables", "*"),
        ]
    )
    if filename and os.path.exists(filename):
        # Verify it's executable Python
        try:
            result = subprocess.run([filename, "--version"], capture_output=True, text=True, timeout=5)
            if result.returncode == 0 and "Python 3.10" in result.stdout:
                config["python"]["binary_path"] = filename
                PYTHON_BINARY = filename
                python_label.config(text=os.path.basename(filename))
                save_settings(config)
                messagebox.showinfo("Success", f"Python binary set:\n{filename}")
                return
            else:
                messagebox.showwarning("Invalid Python", f"Not Python 3.10:\n{filename}")
        except:
            messagebox.showwarning("Invalid Binary", f"Cannot execute:\n{filename}")
    else:
        messagebox.showwarning("No File", "Please select a valid Python binary.")

python_btn = tk.Button(
    add_bar,
    text="Python Path",
    font=("Arial", 10, "bold"),
    bg="orange",
    fg="black",
    command=set_python_path
)
python_btn.pack(side="left", padx=5, pady=5)

python_label = tk.Label(
    add_bar,
    text=os.path.basename(PYTHON_BINARY),
    font=("Arial", 10),
    bg=FRAME5_BG,
    fg="white",
    anchor="w",
    width=20
)
python_label.pack(side="left", padx=2, pady=5)

path_separator = tk.Label(add_bar, text="  ", font=("Arial", 12), bg=FRAME5_BG, fg="white")
path_separator.pack(side="left", padx=5, pady=5)

# Add Path button (now after Python path)
add_btn = tk.Button(
    add_bar,
    text="+ Add Path",
    font=("Arial", 12),
    command=lambda: add_path_entry()
)
add_btn.pack(side="left", pady=5)

# ==============================
# SCROLLABLE PATH FRAME (STRICT 2 COLUMNS)
# ==============================
frame5_container = tk.Frame(
    root,
    bg=config["colors"]["frame5_bg"],
    highlightbackground=config["colors"]["border_color"],
    highlightthickness=2,
    height=650,
    width=width,
)
frame5_container.pack(fill="both", expand=True)
frame5_container.pack_propagate(False)

canvas5 = tk.Canvas(
    frame5_container,
    bg=config["colors"]["frame5_bg"],
    highlightthickness=0
)
scrollbar5 = tk.Scrollbar(frame5_container, orient="vertical", command=canvas5.yview)
scrollable_frame5 = tk.Frame(canvas5, bg=config["colors"]["frame5_bg"])

scrollable_frame5.bind(
    "<Configure>",
    lambda e: canvas5.configure(scrollregion=canvas5.bbox("all"))
)

canvas5.create_window((0, 0), window=scrollable_frame5, anchor="nw")
canvas5.configure(yscrollcommand=scrollbar5.set)

canvas5.pack(side="left", fill="both", expand=True)
scrollbar5.pack(side="right", fill="y")

frames = {}
frames["frame5"] = scrollable_frame5

# strict two columns, equal width with tunable minsize
frames["frame5"].columnconfigure(0, weight=1, uniform="paths", minsize=PATH_COLUMN_WIDTH)
frames["frame5"].columnconfigure(1, weight=1, uniform="paths", minsize=PATH_COLUMN_WIDTH)

def _on_mousewheel(event):
    canvas5.yview_scroll(int(-1*(event.delta/120)), "units")

canvas5.bind_all("<MouseWheel>", _on_mousewheel)                        # Windows
canvas5.bind_all("<Button-4>", lambda e: canvas5.yview_scroll(-1, "units"))  # Linux up
canvas5.bind_all("<Button-5>", lambda e: canvas5.yview_scroll(1, "units"))   # Linux down

# ==============================
# PATH ENTRIES (NO ENTRY WIDGETS)
# ==============================
path_entries = []

def save_paths_to_config():
    config["paths"] = {}
    for i, entry_data in enumerate(path_entries):
        path = entry_data['var'].get().strip()
        if path:
            config["paths"][f"path_{i}"] = path
    save_settings(config)

def run_path(entry_var):
    path = entry_var.get().strip()
    if not path:
        messagebox.showwarning("No Path", "Please select a path first.")
        return

    try:
        try:
            parts = shlex.split(path)
        except:
            parts = path.split()

        if not parts:
            messagebox.showwarning("No Path", "Please select a valid path.")
            return

        executable = parts[0]
        args = parts[1:] if len(parts) > 1 else []

        cwd = None

        if executable.lower() in ['python', 'python3', 'python.exe', 'python3.exe'] and len(args) > 0:
            script_path = args[0]
            if not os.path.exists(script_path):
                messagebox.showerror("Path Error", f"Script does not exist:\n{script_path}")
                return
            cwd = os.path.dirname(os.path.abspath(script_path))
            subprocess.Popen([PYTHON_BINARY] + args, cwd=cwd, env=os.environ.copy())
        elif executable in ['bash', 'sh']:
            if len(args) > 0:
                script_path = args[0]
                if not os.path.exists(script_path):
                    messagebox.showerror("Path Error", f"Script does not exist:\n{script_path}")
                    return
                cwd = os.path.dirname(os.path.abspath(script_path))
            subprocess.Popen([executable] + args, cwd=cwd, env=os.environ.copy())
        else:
            if not os.path.exists(executable) and not os.path.isabs(executable):
                import shutil
                found = shutil.which(executable)
                if not found:
                    messagebox.showerror("Path Error", f"Executable not found:\n{executable}")
                    return
                executable = found
            elif not os.path.exists(executable):
                messagebox.showerror("Path Error", f"Path does not exist:\n{executable}")
                return

            cwd = os.path.dirname(os.path.abspath(executable))

            if executable.endswith('.py'):
                cmd = [PYTHON_BINARY, executable] + args
            elif executable.endswith('.sh'):
                cmd = ['bash', executable] + args
            else:
                cmd = [executable] + args

            subprocess.Popen(cmd, cwd=cwd, env=os.environ.copy())

    except Exception as e:
        messagebox.showerror("Execution Error", f"Failed to run:\n{path}\n\nError: {str(e)}")

def remove_path_entry(idx):
    if idx < len(path_entries):
        # Confirmation popup before removing
        confirm = messagebox.askyesno(
            "Remove Path",
            "Are you sure you want to remove this path entry?"
        )
        if not confirm:
            return

        entry_data = path_entries[idx]
        entry_data['frame'].destroy()
        path_entries.pop(idx)
        refresh_path_layout()
        save_paths_to_config()

def refresh_path_layout():
    for i, entry_data in enumerate(path_entries):
        col = (i % 2)
        row = i // 2
        entry_data['frame'].grid(row=row, column=col, padx=2, pady=2, sticky="nsew")
        entry_data['remove_btn'].config(command=lambda idx=i: remove_path_entry(idx))

def add_path_entry(path=""):
    row_idx = len(path_entries)
    col = (row_idx % 2)
    row = row_idx // 2

    entry_frame = tk.Frame(frames["frame5"], bg=config["colors"]["frame5_bg"])
    entry_frame.grid(row=row, column=col, padx=2, pady=2, sticky="nsew")

    script_name = ""
    if path:
        try:
            parts = shlex.split(path)
            if len(parts) > 0:
                if parts[0] in ['python', 'python3', 'bash', 'sh'] and len(parts) > 1:
                    script_name = os.path.basename(parts[1])
                else:
                    script_name = os.path.basename(parts[0])
        except:
            script_name = os.path.basename(path.split()[0]) if path else ""

    entry_var = tk.StringVar(value=path)

    name_label = tk.Label(
        entry_frame,
        text=script_name if script_name else "[New]",
        bg=config["colors"]["frame5_bg"],
        fg=config["colors"]["frame5_fg"],
        anchor="w",
        font=("Courier", 10, "bold"),
        width=SCRIPT_NAME_WIDTH
    )
    # label fills remaining width within its width cap
    name_label.pack(side="left", padx=1, fill="x", expand=True)

    def update_label(new_path):
        if not new_path:
            name_label.config(text="[New]")
        else:
            base = os.path.basename(new_path)
            name_label.config(text=base[:SCRIPT_NAME_WIDTH] if base else "[New]")
        root.after(100, save_paths_to_config)

    def open_browser():
        filename = filedialog.askopenfilename(
            title="Select Script or Binary",
            filetypes=[
                ("Python Scripts", "*.py"),
                ("Executables", "*.exe"),
                ("Shell Scripts", "*.sh"),
                ("All Files", "*.*"),
            ]
        )
        if filename:
            entry_var.set(filename)
            update_label(filename)

    browse_btn = tk.Button(entry_frame, text="Br", width=BUTTON_WIDTH, command=open_browser)
    browse_btn.pack(side="left", padx=1)

    run_btn = tk.Button(entry_frame, text="R", fg="green", width=BUTTON_WIDTH,
                        command=lambda v=entry_var: run_path(v))
    run_btn.pack(side="left", padx=1)

    remove_btn = tk.Button(entry_frame, text="X", fg="red", width=BUTTON_WIDTH,
                           command=lambda idx=row_idx: remove_path_entry(idx))
    remove_btn.pack(side="left", padx=1)

    path_entries.append({
        'frame': entry_frame,
        'var': entry_var,
        'label': name_label,
        'browse_btn': browse_btn,
        'run_btn': run_btn,
        'remove_btn': remove_btn
    })

    save_paths_to_config()

def load_paths_from_config():
    if "paths" in config:
        paths_dict = dict(config["paths"])
        sorted_keys = sorted(
            paths_dict.keys(),
            key=lambda x: int(x.split('_')[1]) if '_' in x and x.split('_')[1].isdigit() else 0
        )
        for key in sorted_keys:
            try:
                path = paths_dict[key]
                if path and path.strip():
                    add_path_entry(path)
            except (KeyError, ValueError):
                continue

load_paths_from_config()

# ==============================
# EXIT CONFIRMATION
# ==============================
def on_closing():
    if not messagebox.askyesno("Exit", "Are you sure you want to exit?"):
        return

    geom = root.geometry()
    size_part, pos_part = geom.split("+", 1)
    w, h = size_part.split("x")
    x, y = pos_part.split("+")

    config["window"]["width"] = w
    config["window"]["height"] = h
    config["window"]["x"] = x
    config["window"]["y"] = y
    save_settings(config)

    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()
